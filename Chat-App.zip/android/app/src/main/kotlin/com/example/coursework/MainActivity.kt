package com.example.coursework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
