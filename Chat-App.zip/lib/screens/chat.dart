//chat.dart

import 'package:coursework/widgets/chat_messages.dart';
import 'package:coursework/widgets/new_message.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffd6dad1),
        appBar: AppBar(
          title: Text('Flutter Chat'),
          actions: [
            IconButton(
                onPressed: () {
                  FirebaseAuth.instance.signOut();
                },
                icon: Icon(
                  Icons.exit_to_app,
                  color: Theme.of(context).colorScheme.primary,
                ))
          ],
          backgroundColor: const Color(0xff32da51),
        ),
        body: Column(
          children: const [
            Expanded(child: ChatMessages()),
            NewMessage(),
          ],
        ));
  }
}
