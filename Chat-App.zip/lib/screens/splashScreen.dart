//splash_screen.dart

import 'package:flutter/material.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 145, 205, 255),
      appBar: AppBar(
        title: Text('Flutter Chat'),
        backgroundColor: Color.fromARGB(255, 145, 205, 255),
      ),
      body: const Center(
        child: Text(
          'Loading....',
          style: TextStyle(
            color: Colors.black,
            fontSize: 30,
          ),
        ),
      ),
    );
  }
}
